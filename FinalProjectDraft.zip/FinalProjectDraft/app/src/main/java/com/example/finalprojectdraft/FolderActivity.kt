package com.example.finalprojectdraft

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Filter
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.collections.getOrPut

data class EntryProgressState(
    var primaryValue: Int = 1,
    var secondaryValue: Int = 1
)

class FolderActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private var categoryId: Int = -1
    private var currentUserId: Int = 1
    private var isFavoritesFolder: Boolean = false

    private val allEntries = mutableListOf<MediaEntry>()
    private val visibleEntries = mutableListOf<MediaEntry>()
    private val progressByEntryId = mutableMapOf<Int, EntryProgressState>()
    private val favoriteIds = mutableSetOf<Int>()
    private lateinit var entryAdapter: MediaEntryRowAdapter

    private val suggestionList = mutableListOf<String>()
    private lateinit var suggestionAdapter: AutoCompleteAdapter

    private val mediaTypes = listOf("Manga", "Webtoon", "Anime", "TV Series", "Movie", "Book")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_folder)

        dbHelper = DatabaseHelper(this)
        currentUserId = resolveValidUserId()

        val folderTitle = findViewById<TextView>(R.id.folderTitle)
        val inputEntryName = findViewById<AutoCompleteTextView>(R.id.inputEntryName)
        val inputSearchEntries = findViewById<EditText>(R.id.inputSearchEntries)
        val btnAddEntry = findViewById<Button>(R.id.btnAddEntry)
        val listViewEntries = findViewById<ListView>(R.id.listViewEntries)
        val btnBack = findViewById<Button>(R.id.btnBack)

        val folderName = intent.getStringExtra("FOLDER_NAME") ?: "Folder"
        categoryId = intent.getIntExtra("CATEGORY_ID", -1)
        isFavoritesFolder = categoryId == MainActivity.FAVORITES_CATEGORY_ID ||
                folderName.equals(MainActivity.FAVORITES_CATEGORY_NAME, ignoreCase = true)
        folderTitle.text = folderName

        if (isFavoritesFolder) {
            inputEntryName.visibility = View.GONE
            btnAddEntry.visibility = View.GONE
        }

        loadFavoriteIds()

        entryAdapter = MediaEntryRowAdapter(
            context = this,
            items = visibleEntries,
            progressMap = progressByEntryId,
            favoriteIds = favoriteIds,
            onToggleFavorite = { entry ->
                toggleFavorite(entry, inputSearchEntries.text.toString())
            },
            onProgressChanged = { entry, newPrimary, newSecondary ->
                val state = progressByEntryId.getOrPut(entry.id) { EntryProgressState() }
                state.primaryValue = newPrimary.coerceAtLeast(1)
                state.secondaryValue = newSecondary.coerceAtLeast(1)
                dbHelper.updateEntryProgress(entry.id, state.primaryValue, state.secondaryValue)
                entryAdapter.notifyDataSetChanged()
            },
            onDeleteClicked = { entry ->
                showDeleteEntryConfirmation(entry, inputSearchEntries.text.toString())
            }
        )
        listViewEntries.adapter = entryAdapter

        suggestionAdapter = AutoCompleteAdapter(this, android.R.layout.simple_dropdown_item_1line, suggestionList)
        inputEntryName.setAdapter(suggestionAdapter)

        loadEntriesFromDatabase()

        btnBack.setOnClickListener {
            finish()
        }

        inputEntryName.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString() ?: ""
                if (query.length >= 2) {
                    val suggestions = dbHelper.searchCatalog(folderName, query)
                    suggestionList.clear()
                    suggestionList.addAll(suggestions)
                    suggestionAdapter.notifyDataSetChanged()
                    if (suggestions.isNotEmpty() && inputEntryName.hasFocus()) {
                        inputEntryName.showDropDown()
                    }
                }
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        inputSearchEntries.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                applySearchFilter(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        btnAddEntry.setOnClickListener {
            val entryName = inputEntryName.text.toString().trim()
            if (entryName.isNotEmpty() && categoryId != -1 && !isFavoritesFolder) {
                showAddEntryDialog(entryName) { selectedType, pVal, sVal ->
                    currentUserId = resolveValidUserId()
                    var newId = dbHelper.addEntry(entryName, selectedType, categoryId, currentUserId)
                    if (newId == -1L) {
                        currentUserId = dbHelper.getDefaultUserId()
                        newId = dbHelper.addEntry(entryName, selectedType, categoryId, currentUserId)
                    }
                    if (newId != -1L) {
                        progressByEntryId[newId.toInt()] = EntryProgressState(pVal, sVal)
                        dbHelper.updateEntryProgress(newId.toInt(), pVal, sVal)
                    }
                    inputEntryName.text.clear()
                    inputSearchEntries.text.clear()
                    loadEntriesFromDatabase()
                }
            }
        }

        listViewEntries.setOnItemClickListener { _, _, position, _ ->
            val entry = visibleEntries[position]
            showProgressDialog(entry, inputSearchEntries.text.toString())
        }

        listViewEntries.setOnItemLongClickListener { _, _, position, _ ->
            val entry = visibleEntries[position]
            val options = arrayOf("Edit Entry Title", "Delete Entry")
            AlertDialog.Builder(this)
                .setTitle(entry.title)
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> showEditEntryDialog(entry, inputSearchEntries.text.toString())
                        1 -> showDeleteEntryConfirmation(entry, inputSearchEntries.text.toString())
                    }
                }
                .show()
            true
        }
    }

    private fun favPrefs() = getSharedPreferences("favorite_entries_user_$currentUserId", Context.MODE_PRIVATE)

    private fun loadFavoriteIds() {
        favoriteIds.clear()
        val saved = favPrefs().getStringSet("ids", emptySet()) ?: emptySet()
        for (idStr in saved) {
            idStr.toIntOrNull()?.let { favoriteIds.add(it) }
        }
    }

    private fun saveFavoriteIds() {
        favPrefs().edit()
            .putStringSet("ids", favoriteIds.map { it.toString() }.toSet())
            .apply()
    }

    private fun toggleFavorite(entry: MediaEntry, currentFilter: String) {
        if (!favoriteIds.add(entry.id)) {
            favoriteIds.remove(entry.id)
        }
        saveFavoriteIds()
        if (isFavoritesFolder) {
            loadEntriesFromDatabase(currentFilter)
        } else {
            entryAdapter.notifyDataSetChanged()
        }
    }

    private fun resolveValidUserId(): Int {
        val sessionPrefs = getSharedPreferences("app_session", Context.MODE_PRIVATE)
        val savedUserId = sessionPrefs.getInt("logged_in_user_id", -1)
        val defaultUserId = dbHelper.getDefaultUserId()

        if (savedUserId == -1) {
            return defaultUserId
        }

        val exists = dbHelper.getAllCategories(savedUserId).isNotEmpty() ||
                dbHelper.getUsername(savedUserId) != "User"
        return if (exists) savedUserId else defaultUserId
    }

    private fun applySearchFilter(rawQuery: String) {
        val filter = rawQuery.trim().lowercase()
        visibleEntries.clear()
        if (filter.isEmpty()) {
            visibleEntries.addAll(allEntries)
        } else {
            visibleEntries.addAll(allEntries.filter { it.title.lowercase().contains(filter) })
        }
        entryAdapter.notifyDataSetChanged()
    }

    private fun showAddEntryDialog(
        entryName: String,
        onSaved: (mediaType: String, primaryVal: Int, secondaryVal: Int) -> Unit
    ) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Add \"$entryName\"")

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 12)
        }

        val labelType = TextView(this).apply {
            text = "Media Type"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        }
        val spinnerMediaType = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@FolderActivity,
                android.R.layout.simple_spinner_dropdown_item,
                mediaTypes
            )
        }

        val inputPrimary = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        val inputSecondary = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        val noteMovie = TextView(this).apply {
            text = "No extra progress parameters needed for a Movie."
            visibility = View.GONE
        }

        container.addView(labelType)
        container.addView(spinnerMediaType)
        container.addView(inputPrimary)
        container.addView(inputSecondary)
        container.addView(noteMovie)
        builder.setView(container)

        spinnerMediaType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                when (mediaTypes[position]) {
                    "Manga" -> {
                        inputPrimary.visibility = View.VISIBLE
                        inputPrimary.hint = "Volume (default 1)"
                        inputSecondary.visibility = View.VISIBLE
                        inputSecondary.hint = "Chapter (default 1)"
                        noteMovie.visibility = View.GONE
                    }
                    "Webtoon" -> {
                        inputPrimary.visibility = View.VISIBLE
                        inputPrimary.hint = "Chapter (default 1)"
                        inputSecondary.visibility = View.GONE
                        inputSecondary.text.clear()
                        noteMovie.visibility = View.GONE
                    }
                    "Anime", "TV Series" -> {
                        inputPrimary.visibility = View.VISIBLE
                        inputPrimary.hint = "Season (default 1)"
                        inputSecondary.visibility = View.VISIBLE
                        inputSecondary.hint = "Episode (default 1)"
                        noteMovie.visibility = View.GONE
                    }
                    "Book" -> {
                        inputPrimary.visibility = View.VISIBLE
                        inputPrimary.hint = "Page (default 1)"
                        inputSecondary.visibility = View.GONE
                        inputSecondary.text.clear()
                        noteMovie.visibility = View.GONE
                    }
                    "Movie" -> {
                        inputPrimary.visibility = View.GONE
                        inputPrimary.text.clear()
                        inputSecondary.visibility = View.GONE
                        inputSecondary.text.clear()
                        noteMovie.visibility = View.VISIBLE
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        builder.setPositiveButton("Save") { _, _ ->
            val selectedType = spinnerMediaType.selectedItem.toString()
            val primaryVal = inputPrimary.text.toString().trim().toIntOrNull()?.coerceAtLeast(1) ?: 1
            val secondaryVal = inputSecondary.text.toString().trim().toIntOrNull()?.coerceAtLeast(1) ?: 1

            onSaved(selectedType, primaryVal, secondaryVal)
            Toast.makeText(this, "Added $entryName ($selectedType)", Toast.LENGTH_SHORT).show()
        }
        builder.setNegativeButton("Cancel", null)
        builder.show()
    }

    private fun loadEntriesFromDatabase(currentFilter: String = "") {
        allEntries.clear()
        val loaded = if (isFavoritesFolder) {
            dbHelper.getAllCategories(currentUserId)
                .flatMap { dbHelper.getEntriesForCategory(it.id) }
                .distinctBy { it.id }
                .filter { favoriteIds.contains(it.id) }
        } else if (categoryId != -1) {
            dbHelper.getEntriesForCategory(categoryId)
        } else {
            emptyList()
        }

        allEntries.addAll(loaded)
        for (entry in loaded) {
            progressByEntryId.putIfAbsent(entry.id, EntryProgressState())
        }
        applySearchFilter(currentFilter)
    }

    private fun showProgressDialog(entry: MediaEntry, currentFilter: String) {
        if (entry.type == "Movie") {
            Toast.makeText(this, "${entry.title} (Movie) has no episode/chapter parameters", Toast.LENGTH_SHORT).show()
            return
        }

        val state = progressByEntryId.getOrPut(entry.id) { EntryProgressState() }
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Update Progress: ${entry.title} (${entry.type})")

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 12)
        }

        val inputPrimary = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(state.primaryValue.toString())
        }
        val inputSecondary = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(state.secondaryValue.toString())
        }

        when (entry.type) {
            "Manga" -> {
                inputPrimary.hint = "Volume"
                inputSecondary.hint = "Chapter"
                container.addView(inputPrimary)
                container.addView(inputSecondary)
            }
            "Webtoon" -> {
                inputPrimary.hint = "Chapter"
                container.addView(inputPrimary)
            }
            "Anime", "TV Series" -> {
                inputPrimary.hint = "Season"
                inputSecondary.hint = "Episode"
                container.addView(inputPrimary)
                container.addView(inputSecondary)
            }
            "Book" -> {
                inputPrimary.hint = "Page"
                container.addView(inputPrimary)
            }
        }

        builder.setView(container)

        builder.setPositiveButton("Save") { _, _ ->
            val newPrimary = inputPrimary.text.toString().trim().toIntOrNull()?.coerceAtLeast(1) ?: state.primaryValue
            val newSecondary = inputSecondary.text.toString().trim().toIntOrNull()?.coerceAtLeast(1) ?: state.secondaryValue
            state.primaryValue = newPrimary
            state.secondaryValue = newSecondary
            dbHelper.updateEntryProgress(entry.id, newPrimary, newSecondary)
            loadEntriesFromDatabase(currentFilter)
            Toast.makeText(this, "Progress updated for ${entry.title}", Toast.LENGTH_SHORT).show()
        }
        builder.setNegativeButton("Cancel", null)
        builder.show()
    }

    private fun showEditEntryDialog(entry: MediaEntry, currentFilter: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Edit Entry Title")

        val input = EditText(this)
        input.setText(entry.title)
        builder.setView(input)

        builder.setPositiveButton("Save") { _, _ ->
            val newTitle = input.text.toString().trim()
            if (newTitle.isNotEmpty()) {
                dbHelper.updateEntry(entry.id, newTitle)
                loadEntriesFromDatabase(currentFilter)
                Toast.makeText(this, "Entry updated", Toast.LENGTH_SHORT).show()
            }
        }
        builder.setNegativeButton("Cancel", null)
        builder.show()
    }

    private fun showDeleteEntryConfirmation(entry: MediaEntry, currentFilter: String) {
        AlertDialog.Builder(this)
            .setTitle("Delete Entry")
            .setMessage("Are you sure you want to delete '${entry.title}'?")
            .setPositiveButton("Delete") { _, _ ->
                dbHelper.deleteEntry(entry.id)
                progressByEntryId.remove(entry.id)
                favoriteIds.remove(entry.id)
                saveFavoriteIds()
                loadEntriesFromDatabase(currentFilter)
                Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

class MediaEntryRowAdapter(
    private val context: Context,
    private val items: List<MediaEntry>,
    private val progressMap: MutableMap<Int, EntryProgressState>,
    private val favoriteIds: Set<Int>,
    private val onToggleFavorite: (MediaEntry) -> Unit,
    private val onProgressChanged: (entry: MediaEntry, newPrimary: Int, newSecondary: Int) -> Unit,
    private val onDeleteClicked: (MediaEntry) -> Unit
) : BaseAdapter() {

    override fun getCount(): Int = items.size
    override fun getItem(position: Int): Any = items[position]
    override fun getItemId(position: Int): Long = items[position].id.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_media_entry, parent, false)
        val entry = items[position]
        val state = progressMap.getOrPut(entry.id) { EntryProgressState() }

        val btnFavoriteStar = view.findViewById<TextView>(R.id.btnFavoriteStar)
        val textEntryTitle = view.findViewById<TextView>(R.id.textEntryTitle)
        val textEntryProgress = view.findViewById<TextView>(R.id.textEntryProgress)
        val btnDeleteEntryRow = view.findViewById<TextView>(R.id.btnDeleteEntryRow)
        val layoutControlsContainer = view.findViewById<LinearLayout>(R.id.layoutControlsContainer)

        val layoutParamOne = view.findViewById<LinearLayout>(R.id.layoutParamOne)
        val textParamOneLabel = view.findViewById<TextView>(R.id.textParamOneLabel)
        val btnParamOneUp = view.findViewById<ImageButton>(R.id.btnParamOneUp)
        val btnParamOneDown = view.findViewById<ImageButton>(R.id.btnParamOneDown)

        val layoutParamTwo = view.findViewById<LinearLayout>(R.id.layoutParamTwo)
        val textParamTwoLabel = view.findViewById<TextView>(R.id.textParamTwoLabel)
        val btnParamTwoUp = view.findViewById<ImageButton>(R.id.btnParamTwoUp)
        val btnParamTwoDown = view.findViewById<ImageButton>(R.id.btnParamTwoDown)

        val isFavorited = favoriteIds.contains(entry.id)
        btnFavoriteStar.text = if (isFavorited) "★" else "☆"

        btnFavoriteStar.setOnClickListener {
            onToggleFavorite(entry)
        }

        textEntryTitle.text = entry.title

        btnDeleteEntryRow.setOnClickListener {
            onDeleteClicked(entry)
        }

        when (entry.type) {
            "Manga" -> {
                textEntryProgress.text = "Volume ${state.primaryValue}, Chapter ${state.secondaryValue}"
                layoutControlsContainer.visibility = View.VISIBLE
                layoutParamOne.visibility = View.VISIBLE
                layoutParamTwo.visibility = View.VISIBLE

                textParamOneLabel.text = "Volume: ${state.primaryValue}"
                textParamTwoLabel.text = "Chapter: ${state.secondaryValue}"

                btnParamOneUp.setOnClickListener {
                    onProgressChanged(entry, state.primaryValue + 1, 1)
                }
                btnParamOneDown.setOnClickListener {
                    if (state.primaryValue > 1) {
                        onProgressChanged(entry, state.primaryValue - 1, 1)
                    }
                }
                btnParamTwoUp.setOnClickListener {
                    onProgressChanged(entry, state.primaryValue, state.secondaryValue + 1)
                }
                btnParamTwoDown.setOnClickListener {
                    if (state.secondaryValue > 1) {
                        onProgressChanged(entry, state.primaryValue, state.secondaryValue - 1)
                    }
                }
            }

            "Webtoon" -> {
                textEntryProgress.text = "Chapter ${state.primaryValue}"
                layoutControlsContainer.visibility = View.VISIBLE
                layoutParamOne.visibility = View.VISIBLE
                layoutParamTwo.visibility = View.GONE

                textParamOneLabel.text = "Chapter: ${state.primaryValue}"

                btnParamOneUp.setOnClickListener {
                    onProgressChanged(entry, state.primaryValue + 1, state.secondaryValue)
                }
                btnParamOneDown.setOnClickListener {
                    if (state.primaryValue > 1) {
                        onProgressChanged(entry, state.primaryValue - 1, state.secondaryValue)
                    }
                }
            }

            "Anime", "TV Series" -> {
                textEntryProgress.text = "Season ${state.primaryValue}, Episode ${state.secondaryValue}"
                layoutControlsContainer.visibility = View.VISIBLE
                layoutParamOne.visibility = View.VISIBLE
                layoutParamTwo.visibility = View.VISIBLE

                textParamOneLabel.text = "Season: ${state.primaryValue}"
                textParamTwoLabel.text = "Episode: ${state.secondaryValue}"

                btnParamOneUp.setOnClickListener {
                    onProgressChanged(entry, state.primaryValue + 1, 1)
                }
                btnParamOneDown.setOnClickListener {
                    if (state.primaryValue > 1) {
                        onProgressChanged(entry, state.primaryValue - 1, 1)
                    }
                }
                btnParamTwoUp.setOnClickListener {
                    onProgressChanged(entry, state.primaryValue, state.secondaryValue + 1)
                }
                btnParamTwoDown.setOnClickListener {
                    if (state.secondaryValue > 1) {
                        onProgressChanged(entry, state.primaryValue, state.secondaryValue - 1)
                    }
                }
            }

            "Book" -> {
                textEntryProgress.text = "Page ${state.primaryValue}"
                layoutControlsContainer.visibility = View.VISIBLE
                layoutParamOne.visibility = View.VISIBLE
                layoutParamTwo.visibility = View.GONE

                textParamOneLabel.text = "Page: ${state.primaryValue}"

                btnParamOneUp.setOnClickListener {
                    onProgressChanged(entry, state.primaryValue + 1, state.secondaryValue)
                }
                btnParamOneDown.setOnClickListener {
                    if (state.primaryValue > 1) {
                        onProgressChanged(entry, state.primaryValue - 1, state.secondaryValue)
                    }
                }
            }

            else -> {
                // Movie (no parameters)
                textEntryProgress.text = "Movie"
                layoutControlsContainer.visibility = View.GONE
            }
        }

        return view
    }
}

class AutoCompleteAdapter(context: Context, resource: Int, private val objects: MutableList<String>) :
    ArrayAdapter<String>(context, resource, objects) {

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val results = FilterResults()
                results.values = objects
                results.count = objects.size
                return results
            }
            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                if (results != null && results.count > 0) {
                    notifyDataSetChanged()
                } else {
                    notifyDataSetInvalidated()
                }
            }
        }
    }
}